from django import forms
from .models import Produtos, Baixa

class ProdutosForm(forms.ModelForm):
	class Meta:
		model = Produtos
		fields = ['Nome_do_Produto', 'Marca', 'Categoria', 'Quantidade', 'Id_Produto']

class BaixaForm(forms.ModelForm):
	class Meta:
		model = Baixa
		fields = ['Nome', 'Id_do_Produto', 'Quantidade_do_Produto']