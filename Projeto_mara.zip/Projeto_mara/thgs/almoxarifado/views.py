from django.shortcuts import render, redirect
from .forms import ProdutosForm, BaixaForm
from .models import Produtos, Baixa

def homepage(request):
	Baixas = Baixa.objects.all()
	return render(request, 'index.html', {'Baixas': Baixas})

def produtos(request):
	Produto = Produtos.objects.all()
	return render(request, 'produtos.html', {'Produto': Produto})

def cadastrar(request):
	if request.method == 'POST':
		form = ProdutosForm(request.POST)
		form.save()
		return redirect('produtos')
	else:
		form = ProdutosForm()
	return render(request, 'cadastrar.html', {'form': form})

def deletar(request, id):
	Produto = Produtos.objects.get(pk=id)
	Produto.delete()
	return redirect('produtos')

def atualizar(request, id):
	Produto = Produtos.objects.get(pk=id)
	form = ProdutosForm(instance=Produto)

	if request.method == 'POST':
		form = ProdutosForm(request.POST, instance=Produto)
		Produto = form.save()
		Produto.save()
		return redirect('produtos')	
	else:
		form = ProdutosForm(instance=Produto)
	return render(request, 'atualizar.html', {'form': form})

def baixar(request):
	if request.method == 'POST':
		form = BaixaForm(request.POST)
		form.save()
		return redirect('homepage')
	else:
		form = BaixaForm()
	return render(request, 'baixar.html', {'form': form})

def deletarbaixa(request, id):
	Baixas = Baixa.objects.get(pk=id)
	Baixas.delete()
	return redirect('homepage')

