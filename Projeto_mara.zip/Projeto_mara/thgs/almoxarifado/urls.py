from django.urls import path
from . import views

urlpatterns = [
    path('', views.homepage, name="homepage"),
    path('produtos/', views.produtos, name="produtos"),
    path('cadastrar/', views.cadastrar, name="cadastrar"),
    path('deletar/<int:id>', views.deletar, name="deletar"),
    path('atualizar/<int:id>', views.atualizar, name="atualizar"),
    path('baixar/', views.baixar, name="baixar"),
    path('deletarbaixa/<int:id>', views.deletarbaixa, name="deletarbaixa")
]