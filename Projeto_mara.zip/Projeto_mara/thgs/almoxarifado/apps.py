from django.apps import AppConfig


class AlmoxarifadoConfig(AppConfig):
    name = 'almoxarifado'
