from django.db import models

class Produtos(models.Model):
	Nome_do_Produto = models.CharField(max_length=20)
	Marca = models.CharField(max_length=20)
	Categoria = models.CharField(max_length=20)
	Quantidade = models.DecimalField(decimal_places=4, max_digits=15)
	Id_Produto = models.CharField(max_length=10)

	def __str__(self):
		return self.Nome_do_Produto

class Baixa(models.Model):
	Nome = models.CharField(max_length=20)
	Id_do_Produto = models.CharField(max_length=10)
	Quantidade_do_Produto = models.DecimalField(decimal_places=4, max_digits=15)
	
	def __str__(self):
		return self.Nome
